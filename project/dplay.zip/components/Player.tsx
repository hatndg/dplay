
import React, { useMemo, useEffect, useRef } from 'react';
import Plyr, { APITypes } from 'plyr-react';
import type { Video } from '../types';
import './Player.css';

interface PlayerProps {
  video: Video;
}

declare global {
  interface Window {
    Hls: any;
  }
}

const Player: React.FC<PlayerProps> = ({ video }) => {
  const ref = useRef<APITypes>(null);

  // Cấu hình cơ bản cho Plyr
  const playerOptions = useMemo(() => ({
    autoplay: true,
    controls: [
        'play-large', 'play', 'progress', 'current-time', 
        'mute', 'volume', 'captions', 'settings', 
        'pip', 'airplay', 'fullscreen'
    ],
    settings: ['captions', 'quality', 'speed', 'loop'],
    captions: { active: true, language: 'en', update: true },
    keyboard: { focused: true, global: true },
    youtube: {
      origin: window.location.origin,
      noCookie: true,
      rel: 0,
    },
    // Quan trọng: Định nghĩa label cho Quality để hiển thị "Auto", "1080p"...
    i18n: {
      qualityLabel: {
        0: 'Auto',
      },
    },
  }), []);

  // Xử lý logic HLS và Source
  useEffect(() => {
    const player = ref.current?.plyr;
    if (!player) return;

    // Reset logic khi video thay đổi
    const Hls = window.Hls;
    let hlsInstance: any = null;

    if (video.type === 'm3u8' && Hls && Hls.isSupported()) {
      hlsInstance = new Hls();
      hlsInstance.loadSource(video.url);
      
      // Plyr đã tạo thẻ video, ta cần attach HLS vào đó
      // Lưu ý: plyr-react render ra một wrapper, ta cần tìm thẻ video bên trong hoặc dùng player.media
      const videoElement = player.media as HTMLMediaElement;
      hlsInstance.attachMedia(videoElement);

      hlsInstance.on(Hls.Events.MANIFEST_PARSED, (event: any, data: any) => {
        // Lấy danh sách các mức chất lượng từ HLS manifest
        const availableQualities = hlsInstance.levels.map((l: any) => l.height);
        // Thêm mức 0 đại diện cho "Auto"
        const qualities = [0, ...availableQualities];

        // Cập nhật cấu hình Quality cho Plyr
        player.config.quality = {
          default: 0, // Mặc định là Auto
          options: qualities,
          forced: true,
          onChange: (newQuality: number) => {
            if (newQuality === 0) {
              hlsInstance.currentLevel = -1; // -1 là chế độ Auto trong hls.js
            } else {
              // Tìm index của level tương ứng với chiều cao (height)
              const levelIndex = hlsInstance.levels.findIndex((l: any) => l.height === newQuality);
              hlsInstance.currentLevel = levelIndex;
            }
          },
        };
        
        // Cập nhật label (hiển thị text thay vì số)
        // Plyr tự động thêm 'p' sau số (vd: 720p), nhưng với 0 ta muốn là 'Auto'
        // Đã cấu hình i18n ở trên cho 0: 'Auto'
      });

    } else if (video.type === 'm3u8' && videoElementCanPlayM3u8()) {
      // Fallback cho Safari (trình duyệt hỗ trợ native HLS)
      player.source = {
        type: 'video',
        sources: [{ src: video.url, type: 'application/x-mpegURL' }],
      };
    } else {
      // Xử lý MP4 hoặc YouTube
      let sources: Plyr.Source[] = [];
      if (video.type === 'youtube') {
        sources = [{ src: video.url, provider: 'youtube' }];
      } else {
        sources = [{ src: video.url, type: 'video/mp4' }];
      }

      player.source = {
        type: 'video',
        sources: sources,
        tracks: video.captions?.map(c => ({ kind: 'captions', ...c })) || []
      } as Plyr.SourceInfo;
    }

    // Cleanup
    return () => {
      if (hlsInstance) {
        hlsInstance.destroy();
      }
    };
  }, [video]);

  // Hàm kiểm tra native HLS support (Safari)
  const videoElementCanPlayM3u8 = () => {
    const video = document.createElement('video');
    return video.canPlayType('application/vnd.apple.mpegurl') || video.canPlayType('application/x-mpegURL');
  };

  // Hàm xử lý khi bấm nút Settings góc trên phải
  const handleTopSettingsClick = () => {
    // Tìm nút settings gốc của Plyr trong DOM và kích hoạt nó
    // Cách này giúp ta tận dụng menu settings có sẵn của Plyr mà không cần code lại UI
    const container = ref.current?.plyr?.elements.container;
    if (container) {
      const settingsBtn = container.querySelector('button[data-plyr="settings"]') as HTMLElement;
      if (settingsBtn) {
        settingsBtn.click();
      }
    }
  };

  return (
    <div className="w-full h-full relative group/player">
       <Plyr
         ref={ref}
         options={playerOptions}
         source={{} as any} // Source được xử lý trong useEffect
        />
        
        {/* Custom Settings Icon - Top Right (YouTube Style) */}
        <button 
          onClick={handleTopSettingsClick}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-sm transition-all duration-300 opacity-0 group-hover/player:opacity-100 focus:opacity-100"
          aria-label="Settings"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
        </button>
    </div>
  );
};

export default Player;
