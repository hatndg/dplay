import React, { useMemo } from 'react';
import Plyr from 'plyr-react';
import type { Video } from '../types';
import './Player.css';

interface PlayerProps {
  video: Video;
}

const Player: React.FC<PlayerProps> = ({ video }) => {

  const plyrSource = useMemo(() => {
    let sources: Plyr.Source[] = [];
    switch (video.type) {
      case 'youtube':
        sources = [{
          src: video.url,
          provider: 'youtube',
        }];
        break;
      case 'm3u8':
        sources = [{
          src: video.url,
          type: 'application/x-mpegURL',
        }];
        break;
      case 'video':
      default:
        sources = [{
          src: video.url,
          type: 'video/mp4',
        }];
        break;
    }

    return {
      type: 'video',
      sources: sources,
      tracks: video.captions?.map(c => ({
        kind: 'captions',
        ...c
      })) || []
    } as Plyr.SourceInfo;

  }, [video]);
  
  const playerOptions = useMemo(() => ({
    autoplay: true,
    controls: [
        'play-large', 'play', 'progress', 'current-time', 
        'mute', 'volume', 'captions', 'settings', 
        'pip', 'airplay', 'fullscreen'
    ],
    settings: ['captions', 'quality', 'speed', 'loop'],
    captions: { active: true, language: 'en', update: true },
    keyboard: { focused: true, global: true },
    youtube: {
      origin: window.location.origin,
      noCookie: true,
      rel: 0,
    }
  }), []);

  return (
    <div className="w-full h-full">
       <Plyr
         source={plyrSource}
         options={playerOptions}
        />
    </div>
  );
};

export default Player;