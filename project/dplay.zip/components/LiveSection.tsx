
import React, { useRef } from 'react';
import type { Video } from '../types';
import VideoCard from './VideoCard';

interface LiveSectionProps {
  items: Video[];
}

const LiveSection: React.FC<LiveSectionProps> = ({ items }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  if (!items || items.length === 0) return null;

  return (
    <div className="my-6 md:my-8 px-4 md:px-10">
      <div className="flex items-center gap-3 mb-4">
        <div className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
        </div>
        <h2 className="text-white text-lg md:text-xl font-bold uppercase tracking-wider">
          Sự Kiện Trực Tiếp
        </h2>
      </div>

      <div className="relative group/live">
        <div 
            ref={scrollRef} 
            className="flex space-x-3 md:space-x-4 overflow-x-auto pb-4 scrollbar-hide snap-x"
        >
          {items.map((video) => (
            <div key={video.id} className="flex-shrink-0 w-[40%] sm:w-[30%] md:w-[22%] lg:w-[18%] snap-start">
              <VideoCard video={video} isLive={true} />
            </div>
          ))}
        </div>
        
        {/* Gradient Fade for scroll indication */}
        <div className="absolute top-0 right-0 w-12 h-full bg-gradient-to-l from-black via-transparent to-transparent pointer-events-none"></div>
      </div>
    </div>
  );
};

export default LiveSection;
