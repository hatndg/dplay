
import React, { useState, FormEvent, useEffect } from 'react';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import Logo from './Logo';

const Header: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [scrolled, setScrolled] = useState(false);

  // Handle scroll effect for header background
  useEffect(() => {
    const handleScroll = () => {
        setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Update query in input when URL changes
  useEffect(() => {
    if (location.pathname === '/search') {
      setQuery(searchParams.get('q') || '');
    } else {
        setQuery(''); // Clear search bar on other pages
    }
  }, [location.pathname, searchParams]);


  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
    }
  };

  const isDplayPage = location.pathname.startsWith('/home') || location.pathname.startsWith('/search') || location.pathname.startsWith('/watch') || location.pathname.startsWith('/offline');

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 p-4 transition-all duration-300 ${scrolled ? 'bg-black/80 backdrop-blur-md border-b border-white/10' : 'bg-gradient-to-b from-black/60 to-transparent border-b border-transparent'}`}>
      <div className="container mx-auto flex items-center justify-between gap-4">
        <Link to="/home">
            <Logo />
        </Link>
        
        {isDplayPage ? (
          <div className="flex items-center gap-4 flex-1">
            <div className="flex-1 flex justify-end md:justify-center">
                <form onSubmit={handleSearch} className="relative w-full max-w-sm">
                <input
                    type="search"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Tìm kiếm theo tiêu đề..."
                    className="w-full bg-black/20 border border-white/20 rounded-md py-2 pl-10 pr-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#ffd193]/50 transition-all"
                    aria-label="Search"
                />
                <button type="submit" aria-label="Submit search" className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </button>
                </form>
            </div>
            <Link to="/offline" className="text-gray-300 hover:text-white transition-colors" title="Nội dung đã lưu">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
            </Link>
          </div>
        ) : (
          <nav className="hidden md:flex items-center space-x-6 text-white">
            <a href="#/home" className="hover:text-[#ffd193] transition-colors">Showcase</a>
            <a href="#/" className="hover:text-[#ffd193] transition-colors">Dịch Vụ</a>
            <a href="#/" className="hover:text-[#ffd193] transition-colors">Về Chúng Tôi</a>
            <a href="#/" className="hover:text-[#ffd193] transition-colors">Liên Hệ</a>
        </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
