
import React from 'react';
import { Link } from 'react-router-dom';
import type { Video } from '../types';

interface VideoCardProps {
  video: Video;
  isLive?: boolean;
}

const VideoCard: React.FC<VideoCardProps> = ({ video, isLive = false }) => {
  return (
    <Link to={`/watch/${video.id}`} className="block group">
      <div className={`aspect-video bg-gray-800 rounded-lg overflow-hidden transition-all duration-300 transform group-hover:scale-105 group-hover:z-10 relative group-hover:ring-2 ring-[#ffd193] ring-offset-2 ring-offset-black ${isLive ? 'border border-red-900/50' : ''}`}>
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300"></div>
        
        {/* Live Badge */}
        {isLive && (
            <div className="absolute top-2 left-2 flex items-center gap-1.5 bg-red-600/90 backdrop-blur-sm px-2 py-0.5 rounded text-[10px] font-bold text-white shadow-lg animate-pulse z-20">
                <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                LIVE
            </div>
        )}

         <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/90 via-black/60 to-transparent opacity-100 transition-opacity duration-300">
            <h3 className={`text-white font-bold truncate ${isLive ? 'text-xs md:text-sm' : 'text-sm'}`}>{video.title}</h3>
            {isLive && <p className="text-[10px] text-gray-300 truncate mt-0.5">Đang phát trực tiếp</p>}
        </div>
      </div>
    </Link>
  );
};

export default VideoCard;
