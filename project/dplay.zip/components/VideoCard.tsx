
import React from 'react';
import { Link } from 'react-router-dom';
import type { Video } from '../types';

interface VideoCardProps {
  video: Video;
}

const VideoCard: React.FC<VideoCardProps> = ({ video }) => {
  return (
    <Link to={`/watch/${video.id}`} className="block group">
      <div className="aspect-video bg-gray-800 rounded-lg overflow-hidden transition-all duration-300 transform group-hover:scale-105 group-hover:z-10 relative group-hover:ring-2 ring-[#ffd193] ring-offset-2 ring-offset-black">
        <img
          src={video.thumbnail}
          alt={video.title}
          className="w-full h-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300"></div>
         <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <h3 className="text-white text-sm font-bold truncate">{video.title}</h3>
        </div>
      </div>
    </Link>
  );
};

export default VideoCard;