import React from 'react';

const Logo: React.FC<{ className?: string }> = ({ className = '' }) => {
  return (
    <div style={{ backgroundColor: '#ffd193' }} className={`flex items-center gap-2 p-1 rounded-md ${className}`}>
      <img
        src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEi4bkh-nOuNDzOrbXljCLNQ9IuuMMK7Z8xPxTWGfAGlLRswHUy9S4wRpvyizMdNyHoernmH3xOJVMgkZwj9iZ2G4jXdfqNSjjIntzrf91kRZADkDV9F48ACuAsI-wIHyOshHzN5ndYIX_6dhHjYUtPq4qnQZ0wFCZXxKIrqn0RtnxIU6g/s500/1725528102390-removebg-preview.png"
        alt="Công Ty Media Logo"
        className="h-8 w-auto"
      />
      <span className="text-2xl font-bold text-black tracking-wider lowercase">dplay</span>
    </div>
  );
};

export default Logo;