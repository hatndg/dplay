import React from 'react';
import { Link } from 'react-router-dom';
import type { Video } from '../types';

interface UpNextProps {
  videos: Video[];
}

const UpNext: React.FC<UpNextProps> = ({ videos }) => {
  if (videos.length === 0) {
    return null;
  }

  return (
    <div className="bg-gray-900 bg-opacity-50 rounded-lg p-4 h-full">
      <h3 className="text-xl font-bold text-white mb-4">Xem Tiếp</h3>
      <div className="flex flex-col space-y-4 max-h-[80vh] overflow-y-auto scrollbar-hide">
        {videos.map(video => (
          <Link to={`/watch/${video.id}`} key={video.id} className="flex items-center group space-x-4 hover:bg-gray-800 p-2 rounded-md transition-colors duration-200">
            <div className="w-32 flex-shrink-0">
              <img src={video.thumbnail} alt={video.title} className="w-full aspect-video object-cover rounded" />
            </div>
            <div className="flex-1">
              <h4 className="text-white font-semibold text-sm line-clamp-2 group-hover:text-[#ffd193] transition-colors duration-200">{video.title}</h4>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

// Helper CSS to hide scrollbar
const style = document.createElement('style');
style.textContent = `
  .scrollbar-hide::-webkit-scrollbar {
    display: none;
  }
  .scrollbar-hide {
    -ms-overflow-style: none;
    scrollbar-width: none;
  }
`;
document.head.append(style);

export default UpNext;