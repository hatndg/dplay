import React from 'react';
import { Link } from 'react-router-dom';
import type { Video } from '../types';

interface HeroProps {
  video: Video;
}

const Hero: React.FC<HeroProps> = ({ video }) => {
  return (
    <div
      className="relative h-[56.25vw] min-h-[400px] max-h-[800px] w-full bg-black overflow-hidden"
    >
      <div
        className="absolute inset-0 w-full h-full bg-cover bg-center hero-bg-animate"
        style={{ backgroundImage: `url(${video.thumbnail})` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent"></div>
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent"></div>
      
      <div className="relative z-10 flex flex-col justify-end pb-16 md:pb-24 h-full text-white px-4 md:px-16 lg:px-24 w-full md:w-2/3 lg:w-1/2">
        <h2 className="text-3xl md:text-5xl lg:text-6xl font-extrabold tracking-tight drop-shadow-lg">
          {video.title}
        </h2>
        <p className="mt-4 text-sm md:text-base lg:text-lg line-clamp-3 drop-shadow-lg">
          {video.description}
        </p>
        <div className="mt-8">
          <Link
            to={`/watch/${video.id}`}
            className="inline-flex items-center px-8 py-3 bg-[#ffd193] hover:bg-opacity-90 text-black font-bold rounded-md transition-all duration-300 ease-in-out transform hover:scale-105 shadow-lg hover:shadow-yellow-500/20"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
            </svg>
            Phát Ngay
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Hero;