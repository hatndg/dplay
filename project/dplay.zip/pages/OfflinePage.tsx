import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Spinner from '../components/Spinner';
import VideoCard from '../components/VideoCard';
import { getAllVideoMetadata } from '../utils/offlineDb';
import type { Video } from '../types';

const OfflinePage: React.FC = () => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const loadVideos = async () => {
      try {
        setLoading(true);
        const savedVideos = await getAllVideoMetadata();
        setVideos(savedVideos);
      } catch (err) {
        setError('Không thể tải nội dung đã lưu.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    loadVideos();
  }, []);

  const renderContent = () => {
    if (loading) {
      return <div className="flex-grow flex items-center justify-center"><Spinner /></div>;
    }

    if (error) {
      return <div className="flex-grow flex items-center justify-center text-[#ffd193]">{error}</div>;
    }
    
    if (searchParams.get('error') === 'not_found') {
        return (
             <div className="flex-grow text-center text-gray-400 pt-16">
                <h2 className="text-2xl mb-2 text-white">Video không tồn tại offline</h2>
                <p>Có thể video đã bị xóa. Vui lòng kiểm tra lại.</p>
            </div>
        )
    }

    if (videos.length === 0) {
      return (
        <div className="flex-grow text-center text-gray-400 pt-16">
          <h2 className="text-2xl mb-2 text-white">Chưa có nội dung nào được lưu</h2>
          <p>Lưu video để xem khi không có mạng.</p>
          <Link to="/home" className="mt-6 inline-block bg-[#ffd193] text-black font-bold py-2 px-6 rounded-md hover:bg-opacity-80 transition-colors">
            Khám phá ngay
          </Link>
        </div>
      );
    }

    return (
      <div className="flex-grow container mx-auto px-4 md:px-10 py-8">
        <h2 className="text-white text-xl md:text-2xl font-bold mb-6">
          Nội Dung Đã Lưu
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 md:gap-4">
          {videos.map(video => (
            // Append ?offline=true to tell WatchPage to load from IndexedDB
            <Link to={`/watch/${video.id}?offline=true`} key={video.id}>
              <VideoCard video={video} />
            </Link>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="bg-black min-h-screen text-white flex flex-col">
      <Header />
      <main className="pt-24 flex-grow flex flex-col">
        {renderContent()}
      </main>
      <Footer />
    </div>
  );
};

export default OfflinePage;
