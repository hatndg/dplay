
import React from 'react';
import { useContent } from '../hooks/useContent';
import Header from '../components/Header';
import Hero from '../components/Hero';
import Carousel from '../components/Carousel';
import LiveSection from '../components/LiveSection';
import Footer from '../components/Footer';
import Spinner from '../components/Spinner';

const HomePage: React.FC = () => {
  const { content, loading, error } = useContent();

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Spinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center text-[#ffd193]">
        Lỗi tải nội dung: {error}
      </div>
    );
  }

  if (!content) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center text-white">
        Không có nội dung.
      </div>
    );
  }

  return (
    <div className="bg-black min-h-screen text-white">
      <Header />
      <main>
        <Hero video={content.hero} />
        
        {/* Live Events Section */}
        {content.liveEvents && content.liveEvents.length > 0 && (
            <div className="pt-8 -mb-4 bg-gradient-to-b from-transparent to-black/20">
                <LiveSection items={content.liveEvents} />
            </div>
        )}

        <div className="py-8 pb-12">
          {content.categories.map((category) => (
            <Carousel key={category.title} category={category} />
          ))}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default HomePage;
