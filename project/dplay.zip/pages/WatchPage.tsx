
import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useContent } from '../hooks/useContent';
import type { Video } from '../types';
import Player from '../components/Player';
import Spinner from '../components/Spinner';
import UpNext from '../components/UpNext';
import * as offlineDb from '../utils/offlineDb';

type OfflineState = 'checking' | 'not_saved' | 'downloading' | 'saved' | 'not_supported';

const WatchPage: React.FC = () => {
  const { videoId } = useParams<{ videoId: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const isOfflineMode = searchParams.get('offline') === 'true';

  const { findVideoById, content, loading: contentLoading, error: contentError } = useContent();
  
  const [video, setVideo] = useState<Video | null>(null);
  const [upNextVideos, setUpNextVideos] = useState<Video[]>([]);
  const [isCopied, setIsCopied] = useState(false);

  const [offlineState, setOfflineState] = useState<OfflineState>('checking');
  const [downloadProgress, setDownloadProgress] = useState(0);

  const checkOfflineStatus = useCallback(async () => {
    if (!videoId || !video) return;

    if (video.type !== 'video') {
        setOfflineState('not_supported');
        return;
    }

    setOfflineState('checking');
    const isSaved = await offlineDb.isVideoSaved(videoId);
    setOfflineState(isSaved ? 'saved' : 'not_saved');
  }, [videoId, video]);

  useEffect(() => {
    // Scroll to top when video ID changes
    window.scrollTo(0, 0);

    const loadVideo = async () => {
      if (!videoId) {
        setVideo(null);
        return;
      }
      
      let foundVideo: Video | undefined | null = null;
      let cleanup: (() => void) | undefined;

      if (isOfflineMode) {
        setOfflineState('saved'); // In offline mode, it's always 'saved'
        const offlineVideo = await offlineDb.getVideo(videoId);
        if (offlineVideo) {
          const blobUrl = URL.createObjectURL(offlineVideo.videoBlob);
          foundVideo = { ...offlineVideo, url: blobUrl };
          cleanup = () => URL.revokeObjectURL(blobUrl);
        } else {
          // Video not found offline, redirect
          navigate('/offline?error=not_found', { replace: true });
          return;
        }
      } else {
        // Online mode
        if (content) {
          foundVideo = findVideoById(videoId);
        }
      }
      
      setVideo(foundVideo || null);

      if (foundVideo && content) {
         let relatedVideos: Video[] = [];
        const currentCategory = content.categories.find(cat => cat.items.some(item => item.id === videoId));
        if (currentCategory) {
          relatedVideos = currentCategory.items.filter(item => item.id !== videoId);
        } else if (content.hero?.id === videoId && content.categories.length > 0) {
          relatedVideos = content.categories[0].items.filter(item => item.id !== videoId);
        }
        setUpNextVideos(relatedVideos);
      }
      
      return cleanup;
    };

    let cleanupPromise = loadVideo();

    return () => {
      cleanupPromise.then(cleanup => cleanup && cleanup());
    };
  }, [videoId, isOfflineMode, content, findVideoById, navigate]);

  useEffect(() => {
    if (video && !isOfflineMode) {
        checkOfflineStatus();
    }
  }, [video, isOfflineMode, checkOfflineStatus]);


  const handleShare = async () => {
    if (!video) return;
    const shareUrl = window.location.origin + window.location.pathname + `#/watch/${video.id}`;
    const shareTitle = video.title;

    if (navigator.share) {
      await navigator.share({ title: shareTitle, url: shareUrl }).catch(e => console.error(e));
    } else {
      await navigator.clipboard.writeText(shareUrl);
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    }
  };

  const handleSaveOffline = async () => {
    if (!video || video.type !== 'video') return;

    setOfflineState('downloading');
    setDownloadProgress(0);

    try {
      const response = await fetch(video.url);
      if (!response.ok || !response.body) throw new Error('Network response was not ok.');

      const reader = response.body.getReader();
      const contentLength = Number(response.headers.get('Content-Length'));
      let receivedLength = 0;
      const chunks: Uint8Array[] = [];

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
        receivedLength += value.length;
        if (contentLength) {
          const progress = Math.round((receivedLength / contentLength) * 100);
          setDownloadProgress(progress);
        }
      }

      const blob = new Blob(chunks);
      await offlineDb.saveVideo(video, blob);
      setOfflineState('saved');
    } catch (error) {
      console.error('Failed to save video for offline:', error);
      alert('Không thể lưu video. Vui lòng thử lại.');
      setOfflineState('not_saved');
    }
  };
  
  const handleDeleteOffline = async () => {
      if (!videoId) return;
      await offlineDb.deleteVideo(videoId);
      setOfflineState('not_saved');
  };

  if (contentLoading && !isOfflineMode) {
    return <div className="min-h-screen bg-black flex items-center justify-center"><Spinner /></div>;
  }

  if (contentError) {
    return <div className="min-h-screen bg-black text-[#ffd193] flex items-center justify-center">Lỗi tải dữ liệu video.</div>;
  }

  if (!video) {
    return (
        <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center">
            <h2 className="text-2xl mb-4">Không tìm thấy video.</h2>
             <button onClick={() => navigate('/home')} className="px-4 py-2 bg-[#ffd193] text-black rounded hover:bg-opacity-80">
                Về Trang Chủ
            </button>
        </div>
    );
  }

  const renderOfflineButton = () => {
    const buttonClasses = "inline-flex items-center justify-center px-5 py-2.5 bg-gray-800 hover:bg-gray-700 text-white font-semibold rounded-lg transition-all duration-300 ease-in-out transform hover:scale-105 shadow-lg disabled:opacity-50 disabled:cursor-not-allowed";
    
    switch (offlineState) {
      case 'saved':
        return (
          <button onClick={handleDeleteOffline} className={buttonClasses}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg>
            <span>Xóa Offline</span>
          </button>
        );
      case 'downloading':
        return (
          <button disabled className={buttonClasses}>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
            <span>Đang tải... ({downloadProgress}%)</span>
          </button>
        );
      case 'not_saved':
        return (
          <button onClick={handleSaveOffline} className={buttonClasses}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
            <span>Lưu Offline</span>
          </button>
        );
       case 'not_supported':
        return (
          <button disabled className={buttonClasses} title="Chỉ hỗ trợ lưu offline cho video MP4.">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" /></svg>
            <span>Không hỗ trợ</span>
          </button>
        );
      default: return null;
    }
  };


  return (
    <div className="bg-black min-h-screen flex flex-col text-white">
       <header className="p-4 flex items-center w-full z-10">
        <button onClick={() => isOfflineMode ? navigate('/offline') : navigate(-1)} className="text-white hover:text-[#ffd193] transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
        </button>
        <h1 className="text-xl font-bold ml-4 truncate">{video.title}</h1>
      </header>
      
      <main className="container mx-auto px-4 py-4 flex flex-col lg:flex-row gap-8">
        <div className="w-full lg:w-2/3 flex flex-col">
          <div className="w-full aspect-video bg-gray-900 rounded-lg overflow-hidden shadow-2xl shadow-yellow-500/10">
            <Player video={video} key={video.id} />
          </div>
          <div className="mt-6">
            <h2 className="text-2xl lg:text-3xl font-bold">{video.title}</h2>
            <p className="mt-2 text-gray-400 max-w-4xl">{video.description}</p>
            
            <div className="mt-6 flex flex-wrap gap-4">
              <button onClick={handleShare} className="inline-flex items-center px-5 py-2.5 bg-gray-800 hover:bg-gray-700 text-white font-semibold rounded-lg transition-all duration-300 ease-in-out transform hover:scale-105 shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12s-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" /></svg>
                <span>{isCopied ? 'Đã sao chép!' : 'Chia sẻ'}</span>
              </button>
              {!isOfflineMode && renderOfflineButton()}
            </div>
          </div>
        </div>

        <aside className="w-full lg:w-1/3">
          {upNextVideos.length > 0 && <UpNext videos={upNextVideos} />}
        </aside>
      </main>
    </div>
  );
};

export default WatchPage;