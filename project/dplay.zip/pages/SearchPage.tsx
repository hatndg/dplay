
import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useContent } from '../hooks/useContent';
import type { Video } from '../types';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Spinner from '../components/Spinner';
import VideoCard from '../components/VideoCard';

const SearchPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  
  const { loading, error, allVideos } = useContent();
  const [searchResults, setSearchResults] = useState<Video[]>([]);

  const allVideosArray = useMemo(() => Array.from(allVideos.values()), [allVideos]);

  useEffect(() => {
    if (query && allVideosArray.length > 0) {
      const lowercasedQuery = query.toLowerCase().trim();
      const results = allVideosArray.filter(video => 
        video.title.toLowerCase().includes(lowercasedQuery) ||
        video.description.toLowerCase().includes(lowercasedQuery)
      );
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  }, [query, allVideosArray]);

  const renderContent = () => {
    if (loading) {
      return <div className="flex-grow flex items-center justify-center"><Spinner /></div>;
    }

    if (error) {
      return <div className="flex-grow flex items-center justify-center text-[#ffd193]">Lỗi tải nội dung: {error}</div>;
    }

    if (!query) {
      return <div className="flex-grow text-center text-gray-400 pt-16">Vui lòng nhập từ khóa để tìm kiếm.</div>;
    }

    return (
      <div className="flex-grow container mx-auto px-4 md:px-10 py-8">
        {searchResults.length > 0 ? (
          <>
            <h2 className="text-white text-xl md:text-2xl font-bold mb-6">
              Kết quả tìm kiếm cho: <span className="text-[#ffd193]">{query}</span>
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2 md:gap-4">
              {searchResults.map(video => (
                <VideoCard key={video.id} video={video} />
              ))}
            </div>
          </>
        ) : (
          <div className="text-center text-gray-400 pt-16">
            <h2 className="text-2xl mb-2">Không tìm thấy kết quả nào cho "{query}"</h2>
            <p>Vui lòng thử với từ khóa khác.</p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-black min-h-screen text-white flex flex-col">
      <Header />
      <main className="pt-24 flex-grow flex flex-col">
        {renderContent()}
      </main>
      <Footer />
    </div>
  );
};

export default SearchPage;
