
import React, { useState, useEffect } from 'react';
import type { VideoContent, Video, Category, CaptionTrack } from '../types';

// Initial Empty State
const initialContent: VideoContent = {
  hero: {
    id: '',
    title: '',
    description: '',
    thumbnail: '',
    url: '',
    type: 'video'
  },
  liveEvents: [],
  categories: []
};

const SAMPLE_URL = 'https://raw.githubusercontent.com/hatndg/dplay/refs/heads/main/fetch/content.json';

const PlaylistManagerPage: React.FC = () => {
  const [content, setContent] = useState<VideoContent>(initialContent);
  const [activeTab, setActiveTab] = useState<'hero' | 'live' | 'categories' | 'json'>('hero');
  const [notification, setNotification] = useState<string | null>(null);
  const [importUrl, setImportUrl] = useState<string>('');
  const [isImporting, setIsImporting] = useState<boolean>(false);

  // Helper to show notification
  const showNotify = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  // Load Sample Data (Replace)
  const loadSample = async () => {
    if (!window.confirm('Thao tác này sẽ thay thế toàn bộ dữ liệu hiện tại bằng dữ liệu mẫu. Bạn có chắc không?')) return;
    try {
      const res = await fetch(SAMPLE_URL);
      const data = await res.json();
      setContent(data);
      showNotify('Đã tải dữ liệu mẫu!');
    } catch (e) {
      showNotify('Lỗi tải dữ liệu mẫu.');
    }
  };

  // Import & Merge Data
  const handleImportMerge = async () => {
    if (!importUrl) {
        showNotify('Vui lòng nhập URL JSON.');
        return;
    }

    try {
        setIsImporting(true);
        const res = await fetch(importUrl);
        if (!res.ok) throw new Error('Không thể truy cập URL');
        const newData: Partial<VideoContent> = await res.json();

        setContent(prev => {
            // 1. Merge Live Events (Append)
            const mergedLive = [...prev.liveEvents, ...(newData.liveEvents || [])];

            // 2. Merge Categories (Smart Merge)
            const mergedCategories = [...prev.categories];
            (newData.categories || []).forEach(newCat => {
                const existingCatIndex = mergedCategories.findIndex(c => c.title === newCat.title);
                if (existingCatIndex >= 0) {
                    // Nếu danh mục đã tồn tại, thêm video vào danh mục đó
                    mergedCategories[existingCatIndex] = {
                        ...mergedCategories[existingCatIndex],
                        items: [...mergedCategories[existingCatIndex].items, ...newCat.items]
                    };
                } else {
                    // Nếu chưa, tạo danh mục mới
                    mergedCategories.push(newCat);
                }
            });

            // 3. Hero: Keep existing unless current is empty
            const newHero = (prev.hero.id === '' && newData.hero) ? newData.hero : prev.hero;

            return {
                hero: newHero,
                liveEvents: mergedLive,
                categories: mergedCategories
            };
        });

        showNotify('Đã gộp dữ liệu thành công!');
        setImportUrl(''); // Clear input
    } catch (e) {
        showNotify('Lỗi Import: ' + (e instanceof Error ? e.message : 'Định dạng sai'));
    } finally {
        setIsImporting(false);
    }
  };

  // Export Logic
  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(content, null, 2));
    showNotify('Đã sao chép JSON vào clipboard!');
  };

  const handleDownloadJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(content, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "content.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  // --- Update Helpers ---

  const updateHero = (field: keyof Video, value: any) => {
    setContent(prev => ({
      ...prev,
      hero: { ...prev.hero, [field]: value }
    }));
  };

  const updateLiveEvent = (index: number, field: keyof Video, value: any) => {
    const newLive = [...content.liveEvents];
    newLive[index] = { ...newLive[index], [field]: value };
    setContent(prev => ({ ...prev, liveEvents: newLive }));
  };

  const addLiveEvent = () => {
    const newVideo: Video = { id: `live_${Date.now()}`, title: 'New Live Event', description: '', thumbnail: '', url: '', type: 'm3u8' };
    setContent(prev => ({ ...prev, liveEvents: [...prev.liveEvents, newVideo] }));
  };

  const removeLiveEvent = (index: number) => {
    const newLive = [...content.liveEvents];
    newLive.splice(index, 1);
    setContent(prev => ({ ...prev, liveEvents: newLive }));
  };

  const updateCategoryTitle = (catIndex: number, title: string) => {
    const newCats = [...content.categories];
    newCats[catIndex].title = title;
    setContent(prev => ({ ...prev, categories: newCats }));
  };

  const addCategory = () => {
    setContent(prev => ({
      ...prev,
      categories: [...prev.categories, { title: 'Danh mục mới', items: [] }]
    }));
  };

  const removeCategory = (index: number) => {
    if (!window.confirm('Bạn có chắc muốn xóa danh mục này?')) return;
    const newCats = [...content.categories];
    newCats.splice(index, 1);
    setContent(prev => ({ ...prev, categories: newCats }));
  };

  const addVideoToCategory = (catIndex: number) => {
    const newCats = [...content.categories];
    const newVideo: Video = { id: `vid_${Date.now()}`, title: 'Video Mới', description: '', thumbnail: '', url: '', type: 'video' };
    newCats[catIndex].items.push(newVideo);
    setContent(prev => ({ ...prev, categories: newCats }));
  };

  const updateCategoryVideo = (catIndex: number, vidIndex: number, field: keyof Video, value: any) => {
    const newCats = [...content.categories];
    newCats[catIndex].items[vidIndex] = { ...newCats[catIndex].items[vidIndex], [field]: value };
    setContent(prev => ({ ...prev, categories: newCats }));
  };

  const removeCategoryVideo = (catIndex: number, vidIndex: number) => {
    const newCats = [...content.categories];
    newCats[catIndex].items.splice(vidIndex, 1);
    setContent(prev => ({ ...prev, categories: newCats }));
  };

  // --- Components ---

  const VideoForm = ({ video, onChange, onDelete, isHero = false }: { 
    video: Video, 
    onChange: (field: keyof Video, value: any) => void, 
    onDelete?: () => void,
    isHero?: boolean
  }) => (
    <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 mb-4">
      <div className="flex justify-between items-start mb-4">
        <h4 className="text-[#ffd193] font-bold text-sm uppercase">{isHero ? 'Hero Video' : video.title || 'Untitled Video'}</h4>
        {!isHero && onDelete && (
          <button onClick={onDelete} className="text-red-400 hover:text-red-300">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" />
            </svg>
          </button>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="col-span-1">
          <label className="block text-xs text-gray-400 mb-1">Tiêu đề</label>
          <input 
            type="text" 
            value={video.title} 
            onChange={e => onChange('title', e.target.value)}
            className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1 text-sm text-white focus:border-[#ffd193] outline-none"
          />
        </div>
        <div className="col-span-1">
          <label className="block text-xs text-gray-400 mb-1">ID (Duy nhất)</label>
          <input 
            type="text" 
            value={video.id} 
            onChange={e => onChange('id', e.target.value)}
            className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1 text-sm text-white focus:border-[#ffd193] outline-none"
          />
        </div>
        <div className="col-span-1">
          <label className="block text-xs text-gray-400 mb-1">Loại Video</label>
          <select 
            value={video.type}
            onChange={e => onChange('type', e.target.value)}
            className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1 text-sm text-white focus:border-[#ffd193] outline-none"
          >
            <option value="video">MP4 Direct Link</option>
            <option value="youtube">YouTube</option>
            <option value="m3u8">HLS Streaming (m3u8)</option>
          </select>
        </div>
        <div className="col-span-1">
          <label className="block text-xs text-gray-400 mb-1">URL Video</label>
          <input 
            type="text" 
            value={video.url} 
            onChange={e => onChange('url', e.target.value)}
            className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1 text-sm text-white focus:border-[#ffd193] outline-none"
          />
        </div>
        <div className="col-span-2">
          <label className="block text-xs text-gray-400 mb-1">URL Thumbnail</label>
          <div className="flex gap-2">
            <input 
                type="text" 
                value={video.thumbnail} 
                onChange={e => onChange('thumbnail', e.target.value)}
                className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1 text-sm text-white focus:border-[#ffd193] outline-none"
            />
            {video.thumbnail && (
                <img src={video.thumbnail} alt="preview" className="h-8 w-14 object-cover rounded bg-gray-700" />
            )}
          </div>
        </div>
        <div className="col-span-2">
          <label className="block text-xs text-gray-400 mb-1">Mô tả</label>
          <textarea 
            value={video.description} 
            onChange={e => onChange('description', e.target.value)}
            rows={2}
            className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1 text-sm text-white focus:border-[#ffd193] outline-none resize-none"
          />
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black text-white font-sans flex flex-col">
      {/* Header */}
      <header className="bg-[#1a1a1a] border-b border-gray-800 p-4 sticky top-0 z-30 shadow-md">
        <div className="container mx-auto">
            {/* Top Row */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-4">
                <div className="flex items-center gap-3">
                    <div style={{ backgroundColor: '#ffd193' }} className="flex items-center justify-center w-8 h-8 rounded text-black font-bold">M</div>
                    <h1 className="text-xl font-bold">Playlist Manager</h1>
                </div>
                <div className="flex gap-2 text-sm">
                    <button onClick={loadSample} className="px-3 py-1.5 rounded bg-gray-700 hover:bg-gray-600 transition" title="Thay thế toàn bộ dữ liệu">Load Mẫu</button>
                    <button onClick={() => { if(window.confirm('Xóa trắng toàn bộ?')) setContent(initialContent) }} className="px-3 py-1.5 rounded bg-red-900/50 hover:bg-red-900 transition text-red-200">Xóa Trắng</button>
                    <div className="w-px h-8 bg-gray-700 mx-2 hidden md:block"></div>
                    <button onClick={handleCopyJson} className="px-4 py-1.5 rounded bg-blue-600 hover:bg-blue-500 transition font-medium">Copy JSON</button>
                    <button onClick={handleDownloadJson} className="px-4 py-1.5 rounded bg-[#ffd193] text-black hover:bg-yellow-400 transition font-bold">Xuất File</button>
                </div>
            </div>

            {/* Import Tool Row */}
            <div className="flex items-center gap-2 bg-gray-900 p-2 rounded-lg border border-gray-700">
                <span className="text-gray-400 text-sm whitespace-nowrap px-2">Nhập từ URL:</span>
                <input 
                    type="text" 
                    value={importUrl}
                    onChange={(e) => setImportUrl(e.target.value)}
                    placeholder="https://example.com/data.json"
                    className="flex-grow bg-black border border-gray-600 rounded px-3 py-1.5 text-sm text-white focus:border-[#ffd193] outline-none"
                />
                 <button 
                    onClick={() => setImportUrl(SAMPLE_URL)}
                    className="px-2 py-1.5 bg-gray-700 hover:bg-gray-600 text-xs text-gray-300 rounded transition whitespace-nowrap border border-gray-600 hover:border-gray-500"
                    title="Dùng link JSON Dplay gốc"
                >
                    Dplay Git
                </button>
                <button 
                    onClick={handleImportMerge}
                    disabled={isImporting}
                    className="px-4 py-1.5 bg-green-700 hover:bg-green-600 disabled:bg-gray-700 text-white rounded text-sm font-bold transition whitespace-nowrap flex items-center gap-2"
                >
                    {isImporting ? 'Đang tải...' : 'Gộp Dữ Liệu'}
                    {!isImporting && <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
                </button>
            </div>
        </div>
      </header>

      {/* Notification Toast */}
      {notification && (
        <div className="fixed bottom-4 right-4 bg-green-600 text-white px-4 py-2 rounded shadow-lg z-50 animate-bounce">
          {notification}
        </div>
      )}

      {/* Main Layout */}
      <main className="flex-grow container mx-auto p-4 flex flex-col lg:flex-row gap-6">
        
        {/* Left Column: Editors */}
        <div className="w-full lg:w-2/3">
          {/* Tabs */}
          <div className="flex border-b border-gray-700 mb-6 overflow-x-auto">
            <button 
                onClick={() => setActiveTab('hero')}
                className={`px-6 py-3 font-medium transition-colors whitespace-nowrap ${activeTab === 'hero' ? 'text-[#ffd193] border-b-2 border-[#ffd193]' : 'text-gray-400 hover:text-white'}`}
            >
                Hero Section
            </button>
            <button 
                onClick={() => setActiveTab('live')}
                className={`px-6 py-3 font-medium transition-colors whitespace-nowrap ${activeTab === 'live' ? 'text-[#ffd193] border-b-2 border-[#ffd193]' : 'text-gray-400 hover:text-white'}`}
            >
                Live Events ({content.liveEvents.length})
            </button>
            <button 
                onClick={() => setActiveTab('categories')}
                className={`px-6 py-3 font-medium transition-colors whitespace-nowrap ${activeTab === 'categories' ? 'text-[#ffd193] border-b-2 border-[#ffd193]' : 'text-gray-400 hover:text-white'}`}
            >
                Danh Mục ({content.categories.length})
            </button>
             <button 
                onClick={() => setActiveTab('json')}
                className={`lg:hidden px-6 py-3 font-medium transition-colors whitespace-nowrap ${activeTab === 'json' ? 'text-[#ffd193] border-b-2 border-[#ffd193]' : 'text-gray-400 hover:text-white'}`}
            >
                Xem JSON
            </button>
          </div>

          {/* Content Area */}
          <div className="min-h-[500px]">
            {activeTab === 'hero' && (
                <div>
                    <h3 className="text-2xl font-bold mb-4">Cấu Hình Hero Banner</h3>
                    <p className="text-gray-400 mb-6 text-sm">Video nổi bật hiển thị lớn nhất trên trang chủ.</p>
                    <VideoForm video={content.hero} onChange={updateHero} isHero={true} />
                </div>
            )}

            {activeTab === 'live' && (
                <div>
                    <div className="flex justify-between items-center mb-6">
                         <div>
                            <h3 className="text-2xl font-bold">Sự Kiện Trực Tiếp</h3>
                            <p className="text-gray-400 text-sm">Danh sách các kênh TV hoặc sự kiện đang diễn ra.</p>
                         </div>
                         <button onClick={addLiveEvent} className="bg-gray-800 hover:bg-gray-700 text-[#ffd193] px-3 py-1.5 rounded text-sm border border-[#ffd193]/30">+ Thêm Kênh</button>
                    </div>
                    {content.liveEvents.length === 0 ? (
                        <div className="text-center py-10 border border-dashed border-gray-700 rounded-lg text-gray-500">Chưa có kênh nào. Hãy thêm mới.</div>
                    ) : (
                        content.liveEvents.map((vid, idx) => (
                            <VideoForm 
                                key={idx} 
                                video={vid} 
                                onChange={(field, val) => updateLiveEvent(idx, field, val)} 
                                onDelete={() => removeLiveEvent(idx)}
                            />
                        ))
                    )}
                </div>
            )}

            {activeTab === 'categories' && (
                <div>
                    <div className="flex justify-between items-center mb-6">
                         <div>
                            <h3 className="text-2xl font-bold">Danh Mục Phim</h3>
                            <p className="text-gray-400 text-sm">Quản lý các hàng (carousel) hiển thị trên trang chủ.</p>
                         </div>
                         <button onClick={addCategory} className="bg-[#ffd193] text-black px-4 py-2 rounded font-bold shadow hover:bg-yellow-400">+ Thêm Danh Mục</button>
                    </div>

                    {content.categories.map((cat, catIdx) => (
                        <div key={catIdx} className="bg-[#111] border border-gray-800 rounded-xl p-4 mb-8">
                            <div className="flex justify-between items-center mb-4 pb-4 border-b border-gray-800">
                                <div className="flex-1 mr-4">
                                    <label className="text-xs text-[#ffd193] block mb-1 font-bold">Tên Danh Mục</label>
                                    <input 
                                        type="text" 
                                        value={cat.title} 
                                        onChange={(e) => updateCategoryTitle(catIdx, e.target.value)}
                                        className="w-full bg-transparent text-xl font-bold text-white outline-none border-b border-transparent focus:border-[#ffd193] transition-colors"
                                    />
                                </div>
                                <div className="flex items-center gap-2">
                                     <button onClick={() => addVideoToCategory(catIdx)} className="text-sm bg-gray-800 hover:bg-gray-700 px-3 py-1.5 rounded text-gray-200">+ Thêm Video</button>
                                     <button onClick={() => removeCategory(catIdx)} className="text-sm text-red-500 hover:text-red-400 p-2" title="Xóa danh mục">
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" /></svg>
                                     </button>
                                </div>
                            </div>
                            
                            <div className="space-y-4 pl-2 border-l-2 border-gray-800">
                                {cat.items.length === 0 && <p className="text-sm text-gray-500 italic">Danh mục này trống.</p>}
                                {cat.items.map((vid, vidIdx) => (
                                    <VideoForm 
                                        key={vid.id}
                                        video={vid}
                                        onChange={(field, val) => updateCategoryVideo(catIdx, vidIdx, field, val)}
                                        onDelete={() => removeCategoryVideo(catIdx, vidIdx)}
                                    />
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {activeTab === 'json' && (
                 <div className="lg:hidden bg-[#111] p-4 rounded-lg overflow-auto max-h-[70vh] border border-gray-800">
                    <pre className="text-xs text-green-400 font-mono whitespace-pre-wrap break-all">
                        {JSON.stringify(content, null, 2)}
                    </pre>
                </div>
            )}
          </div>
        </div>

        {/* Right Column: JSON Preview (Sticky) */}
        <div className="hidden lg:block w-1/3">
            <div className="sticky top-24 bg-[#111] p-4 rounded-lg border border-gray-800 h-[calc(100vh-8rem)] flex flex-col">
                <div className="flex justify-between items-center mb-2">
                    <h4 className="font-bold text-gray-400">Live JSON Preview</h4>
                    <span className="text-xs text-gray-600">{JSON.stringify(content).length} chars</span>
                </div>
                <div className="flex-grow overflow-auto bg-black rounded p-2 custom-scrollbar">
                    <pre className="text-xs text-green-400 font-mono whitespace-pre-wrap break-all">
                        {JSON.stringify(content, null, 2)}
                    </pre>
                </div>
            </div>
        </div>

      </main>
    </div>
  );
};

export default PlaylistManagerPage;
