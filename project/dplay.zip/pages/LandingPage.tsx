
import React from 'react';
import { Link } from 'react-router-dom';
import Logo from '../components/Logo';

// FIX: Changed JSX.Element to React.ReactElement to resolve "Cannot find namespace 'JSX'" error.
const ServiceCard = ({ icon, title, description }: { icon: React.ReactElement, title: string, description: string }) => (
    <div className="bg-white/5 backdrop-blur-sm p-6 rounded-lg text-center border border-white/10 transform hover:-translate-y-2 transition-transform duration-300">
        <div className="flex justify-center items-center h-16 w-16 mx-auto mb-4 bg-[#ffd193] rounded-full">
            {icon}
        </div>
        <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
        <p className="text-gray-400 text-sm">{description}</p>
    </div>
);

const LandingPage: React.FC = () => {
  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <div className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden text-center p-4">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20 scale-110"
          style={{ backgroundImage: "url('https://images.unsplash.com/photo-1517673132405-a56a62b18caf?q=80&w=2076&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')" }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/50 to-black"></div>

        <div className="relative z-10 max-w-4xl">
          <Logo className="justify-center" />
          <h1 className="mt-8 text-4xl md:text-6xl font-bold text-white leading-tight">
            Hình Ảnh Sáng Tạo, <br />
            <span className="text-[#ffd193]">Câu Chuyện Hấp Dẫn.</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-gray-300 max-w-2xl mx-auto">
            Chúng tôi là Dũng. Media, một nhà sáng tạo chuyên sản xuất nội dung video chất lượng cao, thu hút và truyền cảm hứng. Khám phá các dự án nổi bật của chúng tôi.
          </p>
          <Link
            to="/home"
            className="mt-12 inline-block bg-[#ffd193] hover:bg-opacity-80 text-black font-bold text-lg md:text-xl py-4 px-12 rounded-full transition-all duration-300 ease-in-out transform hover:scale-105"
          >
            Mở dplay
          </Link>
        </div>
      </div>

      {/* Services Section */}
      <section id="services" className="py-20 px-4 container mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Dịch Vụ Của Chúng Tôi</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <ServiceCard 
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>}
                title="Thiết kế website"
                description="Thiết kế website ấn tượng, hiện đại, tối ưu hóa trải nghiệm người dùng để nâng tầm thương hiệu của bạn trên không gian số."
            />
            <ServiceCard 
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>}
                title="Video giới thiệu"
                description="Sản xuất video giới thiệu chuyên nghiệp, từ kịch bản đến hậu kỳ, truyền tải thông điệp của bạn một cách súc tích, hấp dẫn."
            />
            <ServiceCard 
                icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-black" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M15 21v-1a6 6 0 00-1.781-4.121M12 11c-1.657 0-3-1.343-3-3s1.343-3 3-3 3 1.343 3 3-1.343 3-3 3z" /></svg>}
                title="Quản trị fanpage"
                description="Phát triển và quản lý nội dung fanpage, xây dựng cộng đồng, tăng tương tác và biến người theo dõi thành khách hàng."
            />
        </div>
      </section>
    

    </div>
  );
};

export default LandingPage;
