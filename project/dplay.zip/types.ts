
export interface CaptionTrack {
  kind?: 'captions' | 'subtitles';
  label: string;
  srclang: string;
  src: string;
  default?: boolean;
}

export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  url: string;
  type: 'youtube' | 'video' | 'm3u8';
  captions?: CaptionTrack[];
}

export interface Category {
  title: string;
  items: Video[];
}

export interface VideoContent {
  hero: Video;
  categories: Category[];
}