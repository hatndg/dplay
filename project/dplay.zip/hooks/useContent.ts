
import { useState, useEffect, useMemo, useCallback } from 'react';
import type { VideoContent, Video } from '../types';

const CONTENT_URL = 'https://raw.githubusercontent.com/hatndg/dplay/refs/heads/main/fetch/content.json';

// Simple in-memory cache
let cachedContent: VideoContent | null = null;

export const useContent = () => {
  const [content, setContent] = useState<VideoContent | null>(cachedContent);
  const [loading, setLoading] = useState<boolean>(!cachedContent);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (cachedContent) {
      setLoading(false);
      return;
    }

    const fetchContent = async () => {
      try {
        setLoading(true);
        const response = await fetch(CONTENT_URL);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data: VideoContent = await response.json();
        cachedContent = data;
        setContent(data);
      } catch (err) {
        console.error('Failed to fetch content:', err);
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    };

    fetchContent();
  }, []);

  const allVideos = useMemo(() => {
    const map = new Map<string, Video>();
    if (content) {
        if (content.hero) map.set(content.hero.id, content.hero);
        
        // Add live events to map
        if (content.liveEvents) {
            content.liveEvents.forEach(video => map.set(video.id, video));
        }

        content.categories.forEach(cat => {
            cat.items.forEach(video => map.set(video.id, video));
        });
    }
    return map;
  }, [content]);

  const findVideoById = useCallback((id: string) => {
    return allVideos.get(id);
  }, [allVideos]);

  return {
    content,
    loading,
    error,
    allVideos,
    findVideoById
  };
};
