
import { useState, useEffect, useMemo, useCallback } from 'react';
import type { VideoContent, Video } from '../types';

const CONTENT_URL = 'https://raw.githubusercontent.com/hatndg/dplay/refs/heads/main/fetch/content.json';

// Simple in-memory cache
let cachedContent: VideoContent | null = null;

export const useContent = () => {
  const [content, setContent] = useState<VideoContent | null>(cachedContent);
  const [loading, setLoading] = useState<boolean>(!cachedContent);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (cachedContent) {
      return;
    }

    const fetchContent = async () => {
      try {
        setLoading(true);
        const response = await fetch(CONTENT_URL);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data: VideoContent = await response.json();
        cachedContent = data;
        setContent(data);
      } catch (e) {
        if (e instanceof Error) {
            setError(e.message);
        } else {
            setError('An unknown error occurred');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchContent();
  }, []);

  const allVideos = useMemo(() => {
    if (!content) return new Map<string, Video>();
    
    const videoMap = new Map<string, Video>();
    if (content.hero) {
        videoMap.set(content.hero.id, content.hero);
    }
    content.categories.forEach(category => {
      category.items.forEach(video => {
        videoMap.set(video.id, video);
      });
    });
    return videoMap;
  }, [content]);

  const findVideoById = useCallback((id: string): Video | undefined => {
    return allVideos.get(id);
  }, [allVideos]);

  // FIX: Expose `allVideos` so it can be used in other components, for example, the search page.
  return { content, loading, error, findVideoById, allVideos };
};
