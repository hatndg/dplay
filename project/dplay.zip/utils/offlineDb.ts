import type { Video } from '../types';

const DB_NAME = 'DplayOfflineDB';
const DB_VERSION = 1;
const STORE_NAME = 'videos';

interface StoredVideo extends Video {
  videoBlob: Blob;
}

let dbPromise: Promise<IDBDatabase>;

const openDB = (): Promise<IDBDatabase> => {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      console.error('IndexedDB error:', request.error);
      reject(new Error('Failed to open IndexedDB.'));
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
  return dbPromise;
};

export const saveVideo = async (video: Video, blob: Blob): Promise<void> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const dataToStore: StoredVideo = { ...video, videoBlob: blob };
    const request = store.put(dataToStore);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
};

export const getVideo = async (id: string): Promise<StoredVideo | undefined> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(id);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

export const getAllVideoMetadata = async (): Promise<Video[]> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.getAll();

        request.onsuccess = () => {
            const results: StoredVideo[] = request.result;
            // Exclude the large blob for performance
            const metadata = results.map(({ videoBlob, ...meta }) => meta);
            resolve(metadata);
        };
        request.onerror = () => reject(request.error);
    });
};


export const deleteVideo = async (id: string): Promise<void> => {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.delete(id);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
};

export const isVideoSaved = async (id: string): Promise<boolean> => {
    const db = await openDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction(STORE_NAME, 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        // Use count for a more performant check than getting the whole record
        const request = store.count(id);

        request.onsuccess = () => {
            resolve(request.result > 0);
        };
        request.onerror = () => reject(request.error);
    });
};
